/********************************************************************************
 * @author grant add 
 * @brief  printf messages using Json format to PC Terminal 
 *
 *
 *
 *********************************************************************************/

#include "stm32f10x.h"
#include "usart1.h"
#include "malloc.h"

//#include <stdlib.h>
#include "cJSON.h"

#define free(x)  myfree(x)

/* Parse text to JSON, then render back to text, and print! */
void doit(const char *text)
{
	char *out;
	cJSON *json;
	
	json=cJSON_Parse(text);
	if (!json) 
    {
        printf("Error before: [%s]\n",cJSON_GetErrorPtr());
    }
    else
	{
		out = cJSON_Print(json);
		cJSON_Delete(json);
		printf("%s\n",out);
		free(out);
	}
}

/* Used by some code below as an example datatype. */
struct record {
    const char *precision;
    double lat,lon;
    const char *address,*city,*state,*zip,*country; 
};

/* Create a bunch of objects as demonstration. */
void demo_test3()
{
	const char *strings[7]={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
	int ids[4]={116,943,234,38793};
	struct record fields[2]={
		{"zip",37.7668,-1.223959e+2,"","SAN FRANCISCO","CA","94107","US"},
		{"zip",37.371991,-1.22026e+2,"","SUNNYVALE","CA","94085","US"}};
	int numbers[3][3]={{0,-1,0},{1,0,0},{0,0,1}};	

	
	cJSON *root,*fmt,*img,*thm,*fld;char *out;int i;	/* declare a few. */

	/* Here we construct some JSON standards, from the JSON site. */
//-----------------------------------------------------------------------------------------
/*
{
	"name":	"Jack (\"Bee\") Nimble",
	"format":	{
		"type":	"rect",
		"width":	1920,
		"height":	1080,
		"interlace":	false,
		"frame rate":	24
	}
}     
*/    
    printf("\r\nDemo Test 3 \r\n");
    
	root=cJSON_CreateObject();	
	cJSON_AddItemToObject(root, "name", cJSON_CreateString("Jack (\"Bee\") Nimble"));
    
	cJSON_AddItemToObject(root, "format", fmt=cJSON_CreateObject());
	cJSON_AddStringToObject(fmt,"type",		"rect");
	cJSON_AddNumberToObject(fmt,"width",		1920);
	cJSON_AddNumberToObject(fmt,"height",		1080);
	cJSON_AddFalseToObject (fmt,"interlace");
	cJSON_AddNumberToObject(fmt,"frame rate",	24);
	
	out=cJSON_Print(root);	
    cJSON_Delete(root);	
    printf("%s\n",out);	
    free(out);	/* Print to text, Delete the cJSON, print it, release the string. */

////------------------------------------------------------------------------------------------------------

/*
["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
*/
	/* Our "days of the week" array: */
	root=cJSON_CreateStringArray(strings,7);
	out=cJSON_Print(root);	
    cJSON_Delete(root);	
    printf("%s\n",out);	free(out);
    
    
////--------------------------------------------------------------------------------------------------------
/*
[[0, -1, 0], [1, 0, 0], [0, 0, 1]]
*/
/* Our matrix: */
//	int numbers[3][3]={{0,-1,0},{1,0,0},{0,0,1}};
	root=cJSON_CreateArray();
	for (i=0; i<3; i++) 
        cJSON_AddItemToArray(root, cJSON_CreateIntArray(numbers[i], 3));

	//cJSON_ReplaceItemInArray(root,1,cJSON_CreateString("Replacement")); 
	//cJSON_ReplaceItemInArray(root,1,cJSON_CreateIntArray(numbers[2], 3)); 
    
	out=cJSON_Print(root);	
    cJSON_Delete(root);	
    printf("%s\n",out);	
    free(out);

//-------------------------------------------------------------------------------------------------
	/* Our "gallery" item: */
//	int ids[4]={116,943,234,38793};
	root=cJSON_CreateObject();
	cJSON_AddItemToObject(root, "Image", img=cJSON_CreateObject());
	cJSON_AddNumberToObject(img,"Width",800);
	cJSON_AddNumberToObject(img,"Height",600);
	cJSON_AddStringToObject(img,"Title","View from 15th Floor");
    
	cJSON_AddItemToObject(img, "Thumbnail", thm=cJSON_CreateObject());
	cJSON_AddStringToObject(thm, "Url", "http:/*www.example.com/image/481989943");
	cJSON_AddNumberToObject(thm,"Height",125);
	cJSON_AddStringToObject(thm,"Width","100");
	cJSON_AddItemToObject(img,"IDs", cJSON_CreateIntArray(ids,4));

	out=cJSON_Print(root);	
    cJSON_Delete(root);	
    printf("%s\n",out);	
    free(out);

	/* Our array of "records": */
//	struct record fields[2]={
//		{"zip",37.7668,-1.223959e+2,"","SAN FRANCISCO","CA","94107","US"},
//		{"zip",37.371991,-1.22026e+2,"","SUNNYVALE","CA","94085","US"}};

	root=cJSON_CreateArray();
	for (i=0;i<2;i++)
	{
		cJSON_AddItemToArray(root,fld=cJSON_CreateObject());
		cJSON_AddStringToObject(fld, "precision", fields[i].precision);
		cJSON_AddNumberToObject(fld, "Latitude", fields[i].lat);
		cJSON_AddNumberToObject(fld, "Longitude", fields[i].lon);
		cJSON_AddStringToObject(fld, "Address", fields[i].address);
		cJSON_AddStringToObject(fld, "City", fields[i].city);
		cJSON_AddStringToObject(fld, "State", fields[i].state);
		cJSON_AddStringToObject(fld, "Zip", fields[i].zip);
		cJSON_AddStringToObject(fld, "Country", fields[i].country);
	}
	
/*	cJSON_ReplaceItemInObject(cJSON_GetArrayItem(root,1),"City",cJSON_CreateIntArray(ids,4)); */
	
	out=cJSON_Print(root);	
    cJSON_Delete(root);	
    printf("%s\n",out);	
    free(out);

}

void demo_test1(void)
{
    int ids[4]={116,943,234,38793};
    int numbers[3][3]={{0,-1,0},{1,0,0},{0,0,1}};	
    cJSON *root,*fmt,*img,*thm;
    char *out;
    int i;
    const char *strings[7]={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};

    printf("\r\nDemo Test 1 \r\n");

	/* Our "Video" datatype: */
	root=cJSON_CreateObject();	
	cJSON_AddItemToObject(root, "name", cJSON_CreateString("Jack (\"Bee\") Nimble"));
	cJSON_AddItemToObject(root, "format", fmt=cJSON_CreateObject());
	cJSON_AddStringToObject(fmt,"type",		"rect");
	cJSON_AddNumberToObject(fmt,"width",		1920);
	cJSON_AddNumberToObject(fmt,"height",		1080);
	//cJSON_AddFalseToObject (fmt,"interlace");
    cJSON_AddTrueToObject (fmt,"interlace");

	cJSON_AddNumberToObject(fmt,"frame rate",	24);
	
	out=cJSON_Print(root);	
    cJSON_Delete(root);	
    printf("%s\n",out);	
    free(out);	/* Print to text, Delete the cJSON, print it, release the string. */


	
	root=cJSON_CreateStringArray(strings,7);
	out=cJSON_Print(root);	cJSON_Delete(root);	printf("%s\n",out);free(out);

	root=cJSON_CreateArray();
	for (i=0;i<3;i++) cJSON_AddItemToArray(root,cJSON_CreateIntArray(numbers[i],3));
		out=cJSON_Print(root);	cJSON_Delete(root);	printf("%s\n",out);	free(out);

	root=cJSON_CreateObject();
	cJSON_AddItemToObject(root, "Image", img=cJSON_CreateObject());
	cJSON_AddNumberToObject(img,"Width",800);
	cJSON_AddNumberToObject(img,"Height",600);
	cJSON_AddStringToObject(img,"Title","View from 15th Floor");
	cJSON_AddItemToObject(img, "Thumbnail", thm=cJSON_CreateObject());
	cJSON_AddStringToObject(thm, "Url", "http:/*www.example.com/image/481989943");
	cJSON_AddNumberToObject(thm,"Height",125);
	cJSON_AddStringToObject(thm,"Width","100");
	cJSON_AddItemToObject(img,"IDs", cJSON_CreateIntArray(ids,4));

	out=cJSON_Print(root);	cJSON_Delete(root);	printf("%s\n",out);	free(out);   
}

void demo_test2(void)
{
	//const char text1[]="{\n\"name\": \"Jack (\\\"Bee\\\") Nimble\", \n\"format\": {\"type\":       \"rect\", \n\"width\":      1920, \n\"height\":     1080, \n\"interlace\":  false,\"frame rate\": 24\n}\n}";	
	const char text2[]="[\"Sunday\", \"Monday\", \"Tuesday\", \"Wednesday\", \"Thursday\", \"Friday\", \"Saturday\"]";
	const char text3[]="[\n    [0, -1, 0],\n    [1, 0, 0],\n    [0, 0, 1]\n	]\n";
	const char text4[]="{\n		\"Image\": {\n			\"Width\":  800,\n			\"Height\": 600,\n			\"Title\":  \"View from 15th Floor\",\n			\"Thumbnail\": {\n				\"Url\":    \"http:/*www.example.com/image/481989943\",\n				\"Height\": 125,\n				\"Width\":  \"100\"\n			},\n			\"IDs\": [116, 943, 234, 38793]\n		}\n	}";
	const char text5[]="[\n	 {\n	 \"precision\": \"zip\",\n	 \"Latitude\":  37.7668,\n	 \"Longitude\": -122.3959,\n	 \"Address\":   \"\",\n	 \"City\":      \"SAN FRANCISCO\",\n	 \"State\":     \"CA\",\n	 \"Zip\":       \"94107\",\n	 \"Country\":   \"US\"\n	 },\n	 {\n	 \"precision\": \"zip\",\n	 \"Latitude\":  37.371991,\n	 \"Longitude\": -122.026020,\n	 \"Address\":   \"\",\n	 \"City\":      \"SUNNYVALE\",\n	 \"State\":     \"CA\",\n	 \"Zip\":       \"94085\",\n	 \"Country\":   \"US\"\n	 }\n	 ]";
    
    printf("\r\nDemo Test 2 \r\n");
    
	/* Process each json textblock by parsing, then rebuilding: */
	//doit(text1);
	doit(text2);	
	doit(text3);
	doit(text4);
	doit(text5);    
}


void board_init(void)
{
	/* USART1 config 9600 8-N-1 */
	USART1_Config();
	NVIC_Configuration();
	mem_init();
	
    printf("Json test Demo \r\n");
    printf("-------------------------------------------------------\r\n");    
}


int main(void)
{	
    board_init();
    
    //demo_test2();
#if 1
    demo_test1();
    demo_test2();
    demo_test3();
#endif
   
    while(1);
}

